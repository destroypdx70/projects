def func_3():
  return "func 3"

def func_4():
  return "func 4"