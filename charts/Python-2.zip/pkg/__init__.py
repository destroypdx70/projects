print("This packstage it is start")

URL = "My girl.com"

import pkg.mod_1, pkg.mod_2