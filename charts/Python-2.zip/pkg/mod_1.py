def func_1():
  return "func 1"

def func_2():
  return "func 2"