'''
for i in range(1, 11):
  print(i)

my_iterable = iter(range(1, 11))
print(my_iterable)
print(next(my_iterable))

for i in range(1, 11):
  print(i)

accum = iter(range(1, 11))
print(next(accum))
'''
for i in range(1, 21):
  print(i)

accum = iter(range(1, 21))
print(next(accum))
print(next(accum))
print(next(accum))
print(next(accum))
print(next(accum))
print(next(accum))
print(next(accum))
print(next(accum))
print(next(accum))




