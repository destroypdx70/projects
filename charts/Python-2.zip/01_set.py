set_countries = {"Col", "Mex", "Bol", "Col"}
print(set_countries)
print(type(set_countries))

set_numbers = {12, 13, 14, 15, 16, 17, 18, 19, 20, 21}
print(set_numbers)

set_types = {1, "Hi", False, 12.2}
print(set_types)

set_from_string = set("Hi")
print(set_from_string)

set_from_tuple = set(("Anyi", "My real love", "My only love", "My real girl"))
print(set_from_tuple)

numbers = [1, 2, 3, 4, 4, 5, 3, 2, 1]
set_numbers = set(numbers)
print(set_numbers)
unique_numbers = list(set_numbers)
print(unique_numbers)



numbers_two = {1, 2, 4, 5, 5, 6, 7, 8}
print(numbers_two)
set_numbers_two = list(numbers_two)
print(set_numbers_two)

strings_two = {"My little child", "My only girl", "My only real love"}
print(strings_two)
set_strings_two = tuple(strings_two)
print(set_strings_two)

string_set = set("Anyi")
print(string_set)


Tuple_set = set(("My real family", "is", "Anyi"))
print(Tuple_set)
Set_Tuple_set = set(Tuple_set)
print(Set_Tuple_set)

my_set = {1, 2, 3, 4, 5, 6, 6, 7, 2, 1}
print(my_set)
my_set_list = list(my_set)
print(my_set_list)

print("Another form =>", list(my_set))
print("By tuple =>", tuple(my_set))

my_tuple = (1, 2, 3, 4, 5, 6, 7, 3, 4, 2, 1)
print("My_tuple =>", my_tuple)
my_set_tuple = set(my_tuple)
print(my_set_tuple)

my_list = ["The whole", "about", "My wife", "is", "AMAZING"]
print(my_list)
my_list_set = set(my_list)
print(my_list_set)

my_set_v2 = set(("My only love", "Always", "Will be", "My only", "LOVE"))
print(my_set_v2)
my_set_v2_tuple = set(my_set_v2)
print(my_set_v2_tuple)

