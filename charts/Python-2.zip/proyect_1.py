my_set = {1, 2, 3, 4, 5, 6, 7}
print(set)
set_tuple = tuple(my_set)
print(set_tuple)

set_v2 = {"Anyi", "My real love", "My only girl"}
print(set_v2)
set_list = list(set_v2)
print(set_list)

my_list = [1.2, 2.3, 4.3, 7.8]
print(my_list)
my_list_set = set(my_list)
print(my_list_set)

my_tuple = ("Noah", "Elizabeth", "Anyi")
print(my_tuple)
my_tuple_set = set(my_tuple)
print(my_tuple_set)

my_list_v2 = set([1, 2, 3, 4])
print(my_list_v2)

my_tuple_v2 = set((2, 3, 4, 5))
print(my_tuple_v2)


