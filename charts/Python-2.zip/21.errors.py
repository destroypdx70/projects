'''
# print(0 / 0)
# print(result)

suma = lambda x, y : x + y
assert suma(2, 2) == 4

print("Hi")

age = input("Write here your age =>")
if age < 18:
  raise Exception("Minors are not allowed")

print("Hi my love")
'''
sum = lambda x, y : x + y
assert sum(45, 21) == 66

age = int(input("Write here your age => "))
if age < 18:
  raise Exception("Minors are not allowed")
















