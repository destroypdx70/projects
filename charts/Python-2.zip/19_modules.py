'''
import sys
print(sys.path)

import re
text = "My number of cell phone is 490 320 890 123, the country code is +57, mi number of lucky is 7"
result = re.findall("[0-9]+", text)
print(text)
print(result)

import time
timestamp = time.time()
local = time.localtime()
print(timestamp)

result = time.asctime(local)
print(result)

import collections
numbers = [1,1,2,3,4,5,6,7,7,6,5,4,3,2,1]
counter = collections.Counter(numbers)
print(counter)

import sys
print(sys.path)

import re
text = "My real only love is Anyi"
result = re.findall("[0-9]+", text)
print(result)

import time
time_stamp = time.time()
local = time.localtime()
print(time_stamp)

result = time.asctime(local)
print(result)

import collections
numbers = [1,2,3,4,4,5,5,6,7,9]
result = collections.Counter(numbers)
print(result)

import sys
print(sys.path)

import re
text = "My phone number only my girlfriends has 78 11 22 77 88"
result = re.findall("[0-9]", text)
print(result)

import time
time_swapt = time.time()
local = time.localtime()
print(time_swapt)

result = time.asctime(local)
print(result)

import collections
numbers = [1,2,3,4,5,5,6,76,7,1,2,3,45,3,2]
result = collections.Counter(numbers)
print(numbers)
print(result)

import sys
print(sys.path)

import re
text = "The only love is my girl and she is the only that has my phone number 67 90 22 44 67"
result = re.findall("[0-9]", text)
print(result)

import time
time_swapth = time.time()
local = time.localtime()
print(time_swapth)

local = time.asctime()
print(local)

import collections
numbers = [1,2,3,4,54,5,3,2,1,2,3]
result = collections.Counter(numbers)
print(numbers)
print(result)

'''
import sys
print(sys.path)

import re 
text = "My only love is the best and always says that She loves me one hundren millions more than me and my number is 8 2 1212 2344"
result = re.findall("[0-9]+", text)

import time
timeswapt = time.time()
local = time.localtime()
print(timeswapt)

local = time.asctime()
print(local)

import collections
numbers = [1,2,3,4,5,1,2,3,4,5]
result = collections.Counter(numbers)
print(result)