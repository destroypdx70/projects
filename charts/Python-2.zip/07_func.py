'''
print("Hi")

def my_print(text):
  print("This is my print")
  print("This is my print number 2")

my_print("This is my text")

def my_print_2(text):
  print(text * 2)

my_print_2("This is my text")
my_print_2("Hi")

a = 10
b = 30

c = a + b

def suma(a, b):
  my_print_2(a + b)

suma(40, 70)
suma(17, 18)
'''
print("Hi")

def my_print():
  print("This is my print")
  print("It is only a function")

my_print()

def my_print_2(value):
  print(value * 2)

my_print_2("I only love Anyi")
my_print_2(2)

def summ(a, b):
  print(a + b)

summ(30, 80)

def mult(a, b):
  print(a * b)

mult(40, 2)

def div(a, b):
  print(a // b)

div(50, 2)






